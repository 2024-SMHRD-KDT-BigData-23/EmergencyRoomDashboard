package com.smhrd.namnam.repository;

import com.smhrd.namnam.entity.MapInfo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MapInfoRepository extends JpaRepository<MapInfo, Long> {
}

