package com.smhrd.namnam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NamnamApplicationTests {

	@Test
	void contextLoads() {
	}

}
