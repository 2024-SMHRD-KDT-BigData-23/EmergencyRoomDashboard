package com.smhrd.namnam.repository;

import com.smhrd.namnam.entity.DeepInfo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DeepInfoRepository extends JpaRepository<DeepInfo, Long> {
}
